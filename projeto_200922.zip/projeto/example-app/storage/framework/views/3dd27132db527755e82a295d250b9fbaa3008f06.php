<?php $__env->startSection('content'); ?>

<section>
    <h1> Pedido </h1>
</section>

<section>
<p>estamos em reforma! não há nada aqui! </p>
    <img src="<?php echo e(url('images/puppy.png')); ?>">
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>