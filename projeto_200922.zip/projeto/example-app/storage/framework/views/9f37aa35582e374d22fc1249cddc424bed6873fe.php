<?php $__env->startSection('content'); ?>

<section>
    <h1> Pedido </h1>
</section>

<section>
    <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ped): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1> <?php echo e($ped->idPedido); ?> </h1>
    <p> <?php echo e($ped->idProdutop); ?> </p>
    <p> <?php echo e($ped->idCategoriaPed); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>