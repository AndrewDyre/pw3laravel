<?php $__env->startSection('content'); ?>

<section>
    <h1> produtos </h1>
</section>

<section>
<?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1> <?php echo e($prod->idProduto); ?></h1>
    <p> <?php echo e($prod->produto); ?></p>
    <p> <?php echo e($prod->produto); ?> </p>
    <p> <?php echo e($prod->idCategoriaPed); ?> </p>
    <P><?php echo e($prod->valor); ?><p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>