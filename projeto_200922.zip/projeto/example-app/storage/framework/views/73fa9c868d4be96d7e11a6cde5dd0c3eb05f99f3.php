<?php $__env->startSection('content'); ?>

<section>
    <h1> cliente </h1>
</section>

<section>
    <img src="<?php echo e(url('images/puppy.jpg')); ?>">
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>