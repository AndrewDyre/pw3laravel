<?php $__env->startSection('content'); ?>

<section> 
    <h1>Nosso contato</h1>
</section>
<section>
<?php $__currentLoopData = $contato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1> <?php echo e($c->idContato); ?> </h1>
    <p> <?php echo e($c->nome); ?> </p>
    <?php echo e($c->email); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>