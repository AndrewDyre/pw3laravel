<?php $__env->startSection('content'); ?>

<section>
    <h1> cliente </h1>
</section>

<section>
<?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1> <?php echo e($cli->idCliente); ?> </h1>
    <p> <?php echo e($cli->nome); ?> </p>
    <p> <?php echo e($cli->dtNasc); ?> </p>
    <p> <?php echo e($cli->estadoCivil); ?> </p>
    <p> <?php echo e($cli->endereco); ?> </p>
    <p> <?php echo e($cli->numero); ?> </p>
    <p> <?php echo e($cli->complemento); ?> </p>
    <p> <?php echo e($cli->cep); ?> </p>
    <p> <?php echo e($cli->cidade); ?> </p>
    <p> <?php echo e($cli->estado); ?> </p>
    <p> <?php echo e($cli->Rg); ?> </p>
    <p> <?php echo e($cli->cpf); ?> </p>
    <p> <?php echo e($cli->email); ?> </p>
    <p> <?php echo e($cli->fone); ?> </p>
    <p> <?php echo e($cli->celular); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>