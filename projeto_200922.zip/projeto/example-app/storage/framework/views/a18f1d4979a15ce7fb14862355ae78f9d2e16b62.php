<?php $__env->startSection('content'); ?>

<section>
    <h1> categoria</h1>
</section>

<section>
<?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <h1> <?php echo e($cat->idCategoria); ?> </h1>
    <p> <?php echo e($cat->categoria); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>