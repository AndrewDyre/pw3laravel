@extends('template.default')
@section('content')

<section>
    <h1> Home </h1>
</section>

<section> 
    <p>estamos em reforma! não há nada aqui! </p>
    <img src="{{url('images/puppy.png')}}">
</section>

@endsection